import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import dao.OrderProcessorRepository;
import dao.OrderProcessorRepositoryImpl;
import entity.Customer;
import entity.Product;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class EcommerceSystemTest {

    OrderProcessorRepository orderProcessorRepository = new OrderProcessorRepositoryImpl();

    @Test
    public void testProductCreation() {
        
        Product product = new Product();
        product.setName("Test Product");
        product.setPrice(10.0);
        product.setDescription("Test Description");
        product.setStockQuantity(100);

   
        boolean isProductCreated = orderProcessorRepository.createProduct(product);

        
        assertTrue(isProductCreated);
    }

    @Test
    public void testProductAddedToCart() {
        Customer customer = new Customer();
        customer.setCustomerId(1); 

    
        Product product = new Product();
        product.setProductId(1); 


        boolean isProductAddedToCart = orderProcessorRepository.addToCart(customer, product, 2);

      
        assertTrue(isProductAddedToCart);
    }

    @Test
    public void testProductOrdered() {
        
        Customer customer = new Customer();
        customer.setCustomerId(1); 
        
        Product product1 = new Product();
        product1.setProductId(1); 
        int quantity1 = 2;

        Product product2 = new Product();
        product2.setProductId(2); 
        int quantity2 = 1;

        List<Map<Product, Integer>> products = new ArrayList<>();
        Map<Product, Integer> productMap = new HashMap<>();
        productMap.put(product1, quantity1);
        products.add(productMap);

        Map<Product, Integer> productMap2 = new HashMap<>();
        productMap2.put(product2, quantity2);
        products.add(productMap2);

        boolean isOrderPlaced = orderProcessorRepository.placeOrder(customer, products, "Test Address");

        assertTrue(isOrderPlaced);
    }

    @Test
    public void testExceptionThrownForCustomerIdNotFound() {

    	Customer customer = new Customer();
        customer.setCustomerId(9999); 
        orderProcessorRepository.addToCart(customer, new Product(), 1);
    }

    @Test
    public void testExceptionThrownForProductIdNotFound() {
        Customer customer = new Customer();
        customer.setCustomerId(1); 
        
        orderProcessorRepository.addToCart(customer, new Product(), 1);
    }
}