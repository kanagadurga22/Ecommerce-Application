package dao;

import entity.Customer;
import entity.Product;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class OrderProcessorRepositoryImpl implements OrderProcessorRepository {

    @Override
    public boolean createProduct(Product product) {
        String sql = "INSERT INTO products (name, price, description, stock_quantity) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, product.getName());
            pstmt.setDouble(2, product.getPrice());
            pstmt.setString(3, product.getDescription());
            pstmt.setInt(4, product.getStockQuantity());

            System.out.println("Executing query: " + pstmt);

            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean createCustomer(Customer customer) {
        String sql = "INSERT INTO customers (name, email, password) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, customer.getName());
            pstmt.setString(2, customer.getEmail());
            pstmt.setString(3, customer.getPassword());

            System.out.println("Executing query: " + pstmt);

            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean deleteProduct(int productId) {
        String sql = "DELETE FROM products WHERE product_id = ?";
        try (Connection conn = DBConnection.getConnect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, productId);

            System.out.println("Executing query: " + pstmt);

            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean deleteCustomer(int customerId) {
        String sql = "DELETE FROM customers WHERE customer_id = ?";
        try (Connection conn = DBConnection.getConnect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, customerId);

            System.out.println("Executing query: " + pstmt);

            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean addToCart(Customer customer, Product product, int quantity) {
        String sql = "INSERT INTO cart (customer_id, product_id, quantity) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, customer.getCustomerId());
            pstmt.setInt(2, product.getProductId());
            pstmt.setInt(3, quantity);

            System.out.println("Executing query: " + pstmt);

            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean removeFromCart(Customer customer, Product product) {
        String sql = "DELETE FROM cart WHERE customer_id = ? AND product_id = ?";
        try (Connection conn = DBConnection.getConnect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, customer.getCustomerId());
            pstmt.setInt(2, product.getProductId());

            System.out.println("Executing query: " + pstmt);

            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<Product> getAllFromCart(Customer customer) {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT p.product_id, p.name, p.price, p.description, p.stock_quantity " +
                     "FROM products p JOIN cart c ON p.product_id = c.product_id " +
                     "WHERE c.customer_id = ?";
        try (Connection conn = DBConnection.getConnect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, customer.getCustomerId());

            System.out.println("Executing query: " + pstmt);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setProductId(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getDouble("price"));
                product.setDescription(rs.getString("description"));
                product.setStockQuantity(rs.getInt("stock_quantity"));
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    @Override
    public boolean placeOrder(Customer customer, List<Map<Product, Integer>> products, String shippingAddress) {
        String orderSql = "INSERT INTO orders (customer_id, order_date, total_price, shipping_address) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnect();
             PreparedStatement orderPstmt = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS)) {

            conn.setAutoCommit(false);

            orderPstmt.setInt(1, customer.getCustomerId());
            orderPstmt.setDate(2, new java.sql.Date(System.currentTimeMillis()));
            double totalPrice = products.stream()
                                        .mapToDouble(map -> map.entrySet().stream() .mapToDouble(e -> e.getKey().getPrice() * e.getValue())   .sum()) .sum();
            orderPstmt.setDouble(3, totalPrice);
            orderPstmt.setString(4, shippingAddress);

            System.out.println("Executing query: " + orderPstmt);

            int orderRows = orderPstmt.executeUpdate();

            if (orderRows > 0) {
                ResultSet generatedKeys = orderPstmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int orderId = generatedKeys.getInt(1);
                    String orderItemSql = "INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)";
                    try (PreparedStatement orderItemPstmt = conn.prepareStatement(orderItemSql)) {
                        for (Map<Product, Integer> map : products) {
                            for (Map.Entry<Product, Integer> entry : map.entrySet()) {
                                orderItemPstmt.setInt(1, orderId);
                                orderItemPstmt.setInt(2, entry.getKey().getProductId());
                                orderItemPstmt.setInt(3, entry.getValue());
                                orderItemPstmt.addBatch();
                            }
                        }
                        System.out.println("Executing batch insert for order items");
                        orderItemPstmt.executeBatch();
                    }
                }
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            try (Connection conn = DBConnection.getConnect()) {
                conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return false;
    }

 
	@Override
    public List<Map<Product, Integer>> getOrdersByCustomer(int customerId) {
        List<Map<Product, Integer>> products = new ArrayList<>();
        String sql = "SELECT p.product_id, p.name, p.price, p.description, p.stock_quantity " +
                     "FROM products p JOIN order_items oi ON p.product_id = oi.product_id " +
                     "JOIN orders o ON oi.order_id = o.order_id " +
                     "WHERE o.customer_id = ?";
        try (Connection conn = DBConnection.getConnect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, customerId);

            System.out.println("Executing query: " + pstmt);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setProductId(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getDouble("price"));
                product.setDescription(rs.getString("description"));
                product.setStockQuantity(rs.getInt("stock_quantity"));
                products.add((Map<Product, Integer>) product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }
}