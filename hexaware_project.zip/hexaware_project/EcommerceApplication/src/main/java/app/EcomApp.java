package app;

import dao.OrderProcessorRepository;
import dao.OrderProcessorRepositoryImpl;
import entity.Customer;
import entity.Product;
import myexceptions.CustomerNotFoundException;
import myexceptions.ProductNotFoundException;

import java.util.*;

public class EcomApp {
    private static OrderProcessorRepository repository = new OrderProcessorRepositoryImpl();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Choose an operation:");
            System.out.println("1. Register Customer");
            System.out.println("2. Create Product");
            System.out.println("3. Delete Product");
            System.out.println("4. Add to cart");
            System.out.println("5. View cart");
            System.out.println("6. Place order");
            System.out.println("7. View Customer Order");
            System.out.println("8. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine();  
            try {
                switch (choice) {
                    case 1:
                        registerCustomer(scanner);
                        break;
                    case 2:
                        createProduct(scanner);
                        break;
                    case 3:
                        deleteProduct(scanner);
                        break;
                    case 4:
                        addToCart(scanner);
                        break;
                    case 5:
                        viewCart(scanner);
                        break;
                    case 6:
                        placeOrder(scanner);
                        break;
                    case 7:
                        viewCustomerOrder(scanner);
                        break;
                    case 8:
                        System.out.println("Exiting...");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (CustomerNotFoundException | ProductNotFoundException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    private static void registerCustomer(Scanner scanner) {
        System.out.println("Enter Customer ID:");
        int customerId = scanner.nextInt();
        scanner.nextLine();  
        System.out.println("Enter Name:");
        String name = scanner.nextLine();
        System.out.println("Enter Email:");
        String email = scanner.nextLine();
        System.out.println("Enter Password:");
        String password = scanner.nextLine();

        Customer customer = new Customer(customerId, name, email, password);
        if (repository.createCustomer(customer)) {
            System.out.println("Customer registered successfully.");
        } else {
            System.out.println("Failed to register customer.");
        }
    }

    private static void createProduct(Scanner scanner) {
        System.out.println("Enter Product ID:");
        int productId = scanner.nextInt();
        scanner.nextLine();  
        System.out.println("Enter Name:");
        String name = scanner.nextLine();
        System.out.println("Enter Price:");
        double price = scanner.nextDouble();
        scanner.nextLine();  
        System.out.println("Enter Description:");
        String description = scanner.nextLine();
        System.out.println("Enter Stock Quantity:");
        int stockQuantity = scanner.nextInt();

        Product product = new Product(productId, name, price, description, stockQuantity);
        if (repository.createProduct(product)) {
            System.out.println("Product created successfully.");
        } else {
            System.out.println("Failed to create product.");
        }
    }

    private static void deleteProduct(Scanner scanner) throws ProductNotFoundException {
        System.out.println("Enter Product ID to delete:");
        int productId = scanner.nextInt();
        if (repository.deleteProduct(productId)) {
            System.out.println("Product deleted successfully.");
        } else {
            throw new ProductNotFoundException("Product not found with ID: " + productId);
        }
    }

    private static void addToCart(Scanner scanner) throws CustomerNotFoundException, ProductNotFoundException {
        System.out.println("Enter Customer ID:");
        int customerId = scanner.nextInt();
        System.out.println("Enter Product ID:");
        int productId = scanner.nextInt();
        System.out.println("Enter Quantity:");
        int quantity = scanner.nextInt();

        Customer customer = new Customer();
        customer.setCustomerId(customerId);
        Product product = new Product();
        product.setProductId(productId);

        if (repository.addToCart(customer, product, quantity)) {
            System.out.println("Product added to cart successfully.");
        } else {
            throw new CustomerNotFoundException("Customer or Product not found.");
        }
    }

    private static void viewCart(Scanner scanner) throws CustomerNotFoundException {
        System.out.println("Enter Customer ID:");
        int customerId = scanner.nextInt();

        Customer customer = new Customer();
        customer.setCustomerId(customerId);

        List<Product> products = repository.getAllFromCart(customer);
        if (products.isEmpty()) {
            throw new CustomerNotFoundException("No products found in the cart for Customer ID: " + customerId);
        } else {
            System.out.println("Products in Cart:");
            for (Product product : products) {
                System.out.println("Product ID: " + product.getProductId() + ", Name: " + product.getName() +
                        ", Price: " + product.getPrice() + ", Quantity: " + product.getStockQuantity());
            }
        }
    }

    private static void placeOrder(Scanner scanner) throws CustomerNotFoundException, ProductNotFoundException {
        System.out.println("Enter Customer ID:");
        int customerId = scanner.nextInt();
        scanner.nextLine();  

        System.out.println("Enter Shipping Address:");
        String shippingAddress = scanner.nextLine();

        Customer customer = new Customer();
        customer.setCustomerId(customerId);

        List<Product> cartProducts = repository.getAllFromCart(customer);
        if (cartProducts.isEmpty()) {
            throw new CustomerNotFoundException("No products found in the cart for Customer ID: " + customerId);
        }

        List<Map<Product, Integer>> products = new ArrayList<>();
        for (Product product : cartProducts) {
            Map<Product, Integer> productMap = new HashMap<>();
            productMap.put(product, product.getStockQuantity());
            products.add(productMap);
        }

        if (repository.placeOrder(customer, products, shippingAddress)) {
            System.out.println("Order placed successfully.");
        } else {
            throw new ProductNotFoundException("Failed to place order. Products not found.");
        }
    }

    private static void viewCustomerOrder(Scanner scanner) throws CustomerNotFoundException {
        System.out.println("Enter Customer ID:");
        int customerId = scanner.nextInt();

        List<Map<Product, Integer>> orders = repository.getOrdersByCustomer(customerId);
        if (orders.isEmpty()) {
            throw new CustomerNotFoundException("No orders found for Customer ID: " + customerId);
        } else {
            System.out.println("Orders:");
            for (Map<Product, Integer> order : orders) {
                for (Map.Entry<Product, Integer> entry : order.entrySet()) {
                    System.out.println("Product ID: " + entry.getKey().getProductId() + ", Name: " + entry.getKey().getName() +
                            ", Quantity: " + entry.getValue());
                }
            }
        }
    }
}